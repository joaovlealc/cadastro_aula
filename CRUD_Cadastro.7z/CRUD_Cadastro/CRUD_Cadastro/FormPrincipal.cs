﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CRUD_Cadastro
{
    public partial class FormPrincipal : Form
    {
        public FormPrincipal()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            int Id = Convert.ToInt32(txtID.Text.Trim());
            Cadastro cadastro = new Cadastro();
            cadastro.Excluir(Id);
            MessageBox.Show("Cadastro excluida com sucesso!");
            List<Cadastro> cadastros = cadastro.listacadastros();
            dgvCadastro.DataSource = cadastros;
            txtID.Text = "";
            txtNome.Text = "";
            txtCelular.Text = "";
            txtEmail.Text = "";
            this.dtpData_nasc.Value = DateTime.Now.Date;
        }

        private void FormPrincipal_Load(object sender, EventArgs e)
        {
            Cadastro cadastro = new Cadastro();
            List<Cadastro> cadastros = cadastro.listacadastros();
            dgvCadastro.DataSource = cadastros;
        }

        private void btnInserir_Click(object sender, EventArgs e)
        {
            Cadastro cadastro = new Cadastro();
            cadastro.Inserir(txtNome.Text, txtCelular.Text, txtEmail.Text, dtpData_nasc.Value);
            MessageBox.Show("Cadastro realizado com sucesso!");
            List<Cadastro> cadastros = cadastro.listacadastros();
            dgvCadastro.DataSource = cadastros;
            txtNome.Text = "";
            txtCelular.Text = "";
            txtEmail.Text = "";
            this.dtpData_nasc.Value = DateTime.Now.Date;
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            int Id = Convert.ToInt32(txtID.Text.Trim());
            Cadastro cadastro = new Cadastro();
            cadastro.Atualizar(Id ,txtNome.Text, txtCelular.Text, txtEmail.Text, dtpData_nasc.Value);
            MessageBox.Show("Cadastro atualizado com sucesso!");
            List<Cadastro> cadastros = cadastro.listacadastros();
            dgvCadastro.DataSource = cadastros;
            txtID.Text = "";
            txtNome.Text = "";
            txtCelular.Text = "";
            txtEmail.Text = "";
            this.dtpData_nasc.Value = DateTime.Now.Date;
        }

        private void btnLocalizar_Click(object sender, EventArgs e)
        {
            int Id = Convert.ToInt32(txtID.Text.Trim());
            Cadastro cadastro = new Cadastro();
            cadastro.Localizar(Id);
            txtNome.Text = cadastro.nome;
            txtCelular.Text = cadastro.celular;
            txtEmail.Text = cadastro.email;
            dtpData_nasc.Value = Convert.ToDateTime(cadastro.data_nasc);
        }

        private void dgvCadastro_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if(e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dgvCadastro.Rows[e.RowIndex];
                txtID.Text = row.Cells[0].Value.ToString();
                txtNome.Text = row.Cells[1].Value.ToString();
                txtCelular.Text = row.Cells[2].Value.ToString();
                txtEmail.Text = row.Cells[3].Value.ToString();
                dtpData_nasc.Value = Convert.ToDateTime(row.Cells[4].Value);
            }
        }
    }
}
