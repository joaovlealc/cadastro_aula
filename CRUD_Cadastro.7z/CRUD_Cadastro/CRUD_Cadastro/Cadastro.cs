﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace CRUD_Cadastro
{
    class Cadastro
    {
        public int Id { get; set; }
        public string nome { get; set; }
        public string celular { get; set; }
        public string email { get; set; }
        public DateTime data_nasc { get; set; }

        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\programas\cadastro_aula-main\CRUD_Cadastro\CRUD_Cadastro\DbCadastro.mdf;Integrated Security=True");

        public List<Cadastro> listacadastros()
        {
            List<Cadastro> li = new List<Cadastro>();
            string sql = "SELECT * FROM Cadastros";
            con.Open();
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Cadastro c = new Cadastro();
                c.Id = (int)dr["Id"];
                c.nome = dr["nome"].ToString();
                c.celular = dr["celular"].ToString();
                c.email = dr["email"].ToString();
                c.data_nasc = Convert.ToDateTime(dr["data_nasc"]);
                li.Add(c);
            }
            dr.Close();
            con.Close();
            return li;
        }

        public void Inserir(string nome, string celular, string email, DateTime data_nasc)
        {
            string dtp = data_nasc.ToString("yyyy/mm/dd");
            string sql = "INSERT INTO Cadastros(nome,celular,email,data_nasc) VALUES('" +nome+ "','" +celular+ "','"+email+ "','" +dtp+ "')";
            con.Open();
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public void Atualizar(int Id, string nome, string celular, string email, DateTime data_nasc)
        {
            string dtp = data_nasc.ToString("yyyy/mm/dd");
            string sql = "UPDATE Cadastros SET nome='" + nome + "',celular='"+celular+"',email='" + email + "','"+dtp+"' WHERE Id='" + Id + "'";
            con.Open();
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public void Excluir(int Id)
        {
            string sql = "DELETE FROM Cadastros WHERE Id='" + Id + "'";
            con.Open();
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public void Localizar(int Id)
        {
            string sql = "SELECT * FROM Cadastros WHERE Id='" + Id + "'";
            con.Open();
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                nome = dr["nome"].ToString();
                celular = dr["celular"].ToString();
                email = dr["email"].ToString();
                data_nasc = Convert.ToDateTime(dr["data_nasc"]);
            }
            dr.Close();
            con.Close();
        }
    }
}
